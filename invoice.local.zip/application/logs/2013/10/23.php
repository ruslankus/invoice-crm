<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-23 06:53:41 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';', expecting T_FUNCTION ~ APPPATH\classes\Controller\Index\Invoice.php [ 289 ] in file:line
2013-10-23 06:53:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2013-10-23 08:29:49 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function d() ~ APPPATH\classes\Controller\Index\Invoice.php [ 75 ] in file:line
2013-10-23 08:29:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line