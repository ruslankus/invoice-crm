<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-04 06:30:11 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Database_MySQL_Result::where() ~ APPPATH\classes\Controller\Index\Cards.php [ 69 ] in file:line
2013-10-04 06:30:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line