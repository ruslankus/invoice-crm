<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-21 05:05:14 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Operation::oder_by() ~ APPPATH\classes\Controller\Index\Cards.php [ 30 ] in file:line
2013-10-21 05:05:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line