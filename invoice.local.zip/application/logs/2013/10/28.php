<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-28 07:32:09 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function url_setopt() ~ APPPATH\classes\Model\XML.php [ 30 ] in file:line
2013-10-28 07:32:09 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2013-10-28 07:38:08 --- CRITICAL: ErrorException [ 1 ]: Call to undefined function url_setopt() ~ APPPATH\classes\Model\XML.php [ 17 ] in file:line
2013-10-28 07:38:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2013-10-28 08:03:27 --- CRITICAL: ErrorException [ 1 ]: Cannot use object of type Session_Native as array ~ APPPATH\classes\Controller\Index\Auth.php [ 41 ] in file:line
2013-10-28 08:03:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2013-10-28 08:10:08 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:11:36 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:14:32 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:18:57 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:20:46 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:28:22 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:31:10 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:49:26 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:50:14 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 08:53:57 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:30:48 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:34:03 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:43:38 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:49:37 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:53:29 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:56:25 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:58:01 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:58:23 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 09:59:40 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:00:07 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:05:22 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:07:25 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:11:27 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:22:09 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:22:50 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:24:27 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:27:57 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:32:14 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:35:02 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:48:03 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 10:48:40 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line
2013-10-28 11:12:18 --- CRITICAL: ErrorException [ 2 ]: simplexml_import_dom() expects parameter 1 to be object, string given ~ APPPATH\classes\Controller\Index\Auth.php [ 32 ] in file:line
2013-10-28 11:12:18 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'simplexml_impor...', 'C:\OpenServer\d...', 32, Array)
#1 C:\OpenServer\domains\invoice.local\application\classes\Controller\Index\Auth.php(32): simplexml_import_dom('<?xml version="...')
#2 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Controller.php(84): Controller_Index_Auth->action_login()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index_Auth))
#5 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Request.php(986): Kohana_Request_Client->execute(Object(Request))
#7 C:\OpenServer\domains\invoice.local\index.php(118): Kohana_Request->execute()
#8 {main} in file:line
2013-10-28 11:21:25 --- CRITICAL: ErrorException [ 2 ]: simplexml_load_file() [function.simplexml-load-file]: I/O warning : failed to load external entity &quot;&lt;?xml version=&quot;1.0&quot;?&gt;&lt;daccount&gt;&lt;credit&gt;702.04&lt;/credit&gt;&lt;curr&gt;EUR&lt;/curr&gt;&lt;/daccount&gt;
&quot; ~ APPPATH\classes\Controller\Index\Auth.php [ 32 ] in file:line
2013-10-28 11:21:25 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'simplexml_load_...', 'C:\OpenServer\d...', 32, Array)
#1 C:\OpenServer\domains\invoice.local\application\classes\Controller\Index\Auth.php(32): simplexml_load_file('<?xml version="...')
#2 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Controller.php(84): Controller_Index_Auth->action_login()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Index_Auth))
#5 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\OpenServer\domains\invoice.local\system\classes\Kohana\Request.php(986): Kohana_Request_Client->execute(Object(Request))
#7 C:\OpenServer\domains\invoice.local\index.php(118): Kohana_Request->execute()
#8 {main} in file:line
2013-10-28 11:29:04 --- ERROR: Exception [ 0 ]: Serialization of 'SimpleXMLElement' is not allowed ~ SYSPATH\classes\Kohana\Session\Native.php [ 68 ] in file:line