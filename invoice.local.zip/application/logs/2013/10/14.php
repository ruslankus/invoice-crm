<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2013-10-14 07:34:02 --- CRITICAL: ErrorException [ 1 ]: Undefined class constant 'base' ~ APPPATH\classes\Controller\Index\Cards.php [ 74 ] in file:line
2013-10-14 07:34:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line