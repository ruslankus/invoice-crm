<?php defined('SYSPATH') OR die('No direct access allowed.');

return array(

	'driver'       => 'File',
	'hash_method'  => 'sha256',
	'hash_key'     => '123456',
	'lifetime'     => 1209600,
	'session_type' => Session::$default,
	'session_key'  => 'auth_user',

	// Username/password combinations for the Auth File driver
	'users' => array(
	 'admin' => '86e822729b78fb193c1544845a1a529db985a70c69a902d96a95fc4678f8ba2c',
     'alice' => '86e822729b78fb193c1544845a1a529db985a70c69a902d96a95fc4678f8ba2c',
     'dima' => '86e822729b78fb193c1544845a1a529db985a70c69a902d96a95fc4678f8ba2c',
     'alex' => '86e822729b78fb193c1544845a1a529db985a70c69a902d96a95fc4678f8ba2c',
	),

);
