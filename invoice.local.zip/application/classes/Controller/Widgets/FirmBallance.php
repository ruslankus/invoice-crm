<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Widgets_FirmBallance extends Controller_Widgets{
    
    public $template = 'widgets/firm_ballance';
    
    public function action_index(){
        
        
    }
    
}