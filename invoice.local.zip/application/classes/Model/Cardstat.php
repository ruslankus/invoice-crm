<?php defined('SYSPATH') or die('No direct script access.');

class Model_Cardstat extends ORM {
    
}