<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Wincache extends Kohana_Cache_Wincache {}